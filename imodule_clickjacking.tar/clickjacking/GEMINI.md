# Lab Labtainer:clickjacking

## Kịch bản
Sinh viên đóng vai kẻ tấn công nhắm vào NovaPay, một ví điện tử giả lập có giao diện hiện đại. NovaPay (container "victim") là web Flask chạy ở cổng 5000, có đăng nhập, trang tổng quan hiển thị số dư và lịch sử giao dịch, và trang /transfer có nút "Xác nhận chuyển tiền". Trang này không gửi header chống nhúng khung nên bị clickjacking được. Container "attacker" chứa trang mồi "Nhận quà tặng 500.000đ" do sinh viên hoàn thiện, trong đó trang NovaPay được nhúng bằng iframe trong suốt đè đúng lên nút "Nhận quà". Nạn nhân tin là bấm nhận quà nhưng thực chất bấm xác nhận chuyển tiền cho tài khoản của kẻ tấn công. Cuối bài sinh viên vá lỗ hổng bằng header phòng thủ.

## Yêu cầu giao diện (quan trọng)
Cả hai web phải đẹp và hiện đại: nền gradient tím-xanh, card bo góc có đổ bóng, nút bo tròn có hiệu ứng hover, bảng giao dịch có màu phân biệt tiền vào/ra, responsive. Chỉ dùng HTML, CSS và SVG viết tay nhúng trong file, font hệ thống (system-ui), không dùng CDN, font ngoài hay ảnh tải từ internet vì container có thể không có mạng. Trang mồi phải trông hấp dẫn như một trang khuyến mãi thật (banner quà tặng, đồng hồ đếm ngược, nút "Nhận quà ngay").

## Cấu hình
Hai container: victim (Flask + Firefox, tài khoản mẫu nạn nhân đã đăng nhập sẵn bằng user "nan_nhan") và attacker (Python http.server cổng 8000, chứa thư mục www/). Dùng base image mặc định của Labtainer, cài flask trong Dockerfile. Victim và attacker truy cập nhau qua tên host.

## 6 task cho sinh viên
Task 1: khởi động lab, đăng nhập NovaPay bằng Firefox, xem trang tổng quan và xác định trang /transfer là trang nhạy cảm cần tấn công.
Task 2: dùng curl -I http://victim:5000/transfer kiểm tra header phản hồi và xác nhận thiếu X-Frame-Options và Content-Security-Policy frame-ancestors.
Task 3: tạo file test.html trên attacker nhúng trang /transfer bằng iframe thường để chứng minh trang có thể bị nhúng.
Task 4: hoàn thiện trang mồi index.html (có sẵn các dòng TODO): đặt iframe opacity 0, dùng position và z-index để chồng khít lên nút "Nhận quà", căn tọa độ sao cho nút "Xác nhận chuyển tiền" nằm đúng dưới nút mồi.
Task 5: thực hiện tấn công, mở trang mồi bằng Firefox khi đã đăng nhập NovaPay, bấm nút nhận quà và kiểm tra trên NovaPay có giao dịch chuyển tiền mới xuất hiện.
Task 6: vá lỗ hổng, thêm header X-Frame-Options: DENY và Content-Security-Policy: frame-ancestors 'none' trong app.py, khởi động lại Flask, chạy lại tấn công và chứng minh iframe bị trình duyệt chặn.

## results.config (mỗi task một result)
task1: log đăng nhập của victim chứa "POST /login". task2: .bash_history chứa "curl -I". task3: .bash_history hoặc stdout chứa "test.html". task4: file index.html chứa "opacity". task5: log victim chứa "POST /transfer". task6: stdout curl chứa "X-Frame-Options". Gemini được phép chọn cách cấu hình khác nếu cách này không chạy được với Labtainer.

## Quy ước chung
Cấu trúc Labtainer chuẩn: config/start.config, config/results.config, dockerfiles/, docs/. Không bao giờ in hoặc ghi mật khẩu, token vào file. Báo cáo viết tiếng Việt theo 7 mục: giới thiệu, nội dung và hướng dẫn, phân tích yêu cầu, thiết kế (có bảng Result), cài đặt và cấu hình, tích hợp và triển khai (Docker Hub, GitHub), thử nghiệm và đánh giá.
